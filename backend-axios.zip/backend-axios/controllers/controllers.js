let GetHome = (req,res) =>{
    let someData = "This is our backend development project"
    res.status(200).render("index.ejs", { someData, newData: "Vaibhavi" })
}

export { GetHome,}