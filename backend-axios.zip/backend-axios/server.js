import express from "express"
import dotenv from "dotenv"
import bodyParser from "body-parser"
import axios from "axios"
import ejs from "ejs"

import {router} from "./router/router.js"

dotenv.config({ path: "./config.env" })
                    
let port = process.env.PORT

let app = express() 

app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

app.use(express.static("./public"))

app.set("view engine", "ejs")

app.use(router)

app.listen(port, () => {
    console.log(`Server is running on port ${port} | http://localhost:${port}`)
})